import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { HomePage } from '../home/home';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  public Username: any;
  public Password: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public alertCtrl: AlertController) {
    this.Username = 'Raju';
  }

  signIn() {
    var username = this.Username;
    var password = this.Password;
    if (username == "Raju" && password == "12345") {
      this.navCtrl.setRoot(HomePage);       
    }
    else {
      this.alertfunction("Access denide!!!", "User id or password is invalid", "custom-alertDanger");
    }
  }
  alertfunction(title, message, classes) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      cssClass: classes,
      buttons: ['OK']
    });
    alert.present();
  }
}
